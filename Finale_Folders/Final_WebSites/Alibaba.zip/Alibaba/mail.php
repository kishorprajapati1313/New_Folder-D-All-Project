<?php 
    

    $to = "brijeshprajapati1050@gmail.com";
    $subject = "collect faund for ile children";
    $body = "can you donate 10 ruppes";
    $header = "From: kjhgfdsa1014@gmail.com";
    
   if(mail($to, $subject, $body, $header)){
    echo "success";
   }else {
    echo "failed";
   }



?>