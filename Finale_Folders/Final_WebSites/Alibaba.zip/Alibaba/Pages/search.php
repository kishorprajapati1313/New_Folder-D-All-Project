<?php
include("../Par/config.php");

if (isset($_GET['search'])) {
    $search = $_GET['search'];
} else {
    $search = '';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Best E-commerce Website</title>
    <link rel="stylesheet" href="../css/product.css">
</head>
<body>
    <header>
        <nav>
                <div class="search">

            <form action="<?php echo SIT; ?>Pages/search.php" method="get">
                <input type="text" name="search" placeholder="Search">
                <button type="submit">Search</button>
            </form>

                </div>
     
            <div class="cart">
                <a href="#"><img src="cart.png" alt="Cart"></a>
                <span>0</span>
            </div>
        </nav>
        <div class="hero">
            <h1>Welcome to the Best E-commerce Website</h1>
            <p>Shop for the latest trends and get amazing deals on your favorite products.</p>
            <button>Shop Now</button>
        </div>
    </header>
    <section class="featured">
        <h2>Featured Products</h2>
        <div class="search">
           
        </div>
        <?php
        if (isset($_GET['search'])) {
            $search = $_GET['search'];

            $sql = "SELECT * FROM `pro` WHERE `name` LIKE '%$search%' OR `description` LIKE '%$search%'";
            $res = mysqli_query($conn, $sql);

            if ($res) {
                $count = mysqli_num_rows($res);

                if ($count > 0) {
                    while ($row = mysqli_fetch_assoc($res)) {
                        $id = $row['id'];
                        $name = $row['name'];
                        $image_name = $row['image_name'];
                        $price = $row['price'];
                        $des = $row['description'];

                        // Output search result item
                        echo "<div class='product'>";
                        if ($image_name != '') {
                            echo "<img src='" . SIT . "images/pro/$image_name' alt='Product'>";
                        } else {
                            echo "No image";
                        }
                        echo "<h3>$name</h3>";
                        echo "<p>$des</p>";
                        echo "<span>$$price</span>";
                        echo "<button>Add to Cart</button>";
                        echo "</div>";
                    }
                } else {
                    echo "No results found.";
                }
            } else {
                echo "Error executing the search query.";
            }
        }
        ?>
    </section>
    <footer>
        <ul>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms of Service</a></li>
            <li><a href="#">Returns and Refunds</a></li>
        </ul>
        <p>© 2023 Best E-commerce Website</p>
    </footer>
</body>
</html>
