<?php include("../Par/config.php"); 
if (isset($_POST['submit'])){
	$search = $_POST['search'];
	header("location:".SIT."Pages/search.php?search=$search");	
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Best E-commerce Website</title>
	<link rel="stylesheet" href="../css/product.css">
</head>
<body>
	<header>
		<nav>
			<ul>
				<li><a href="#">Home</a></li>
				<li><a href="#">Shop</a></li>
				<li><a href="#">About</a></li>
				<li><a href="#">Contact</a></li>
			</ul>
			
			<form method="post">
			<div class="search">
			<input type="text" name="search" placeholder="Search" >
				<button type='submit' name='submit'> Search </button>
			</div>
			</form>
			<div class="cart">
				<a href="#"><img src="cart.png" alt="Cart"></a>
				<span>0</span>
			</div>
		</nav>
		<div class="hero">
			<h1>Welcome to the Best E-commerce Website</h1>
			<p>Shop for the latest trends and get amazing deals on your favorite products.</p>
			<button>Shop Now</button>
		</div>
	</header>
	<section class="featured">
			<h2>Featured Products</h2>
		<?php
				
				$sql = "SELECT * FROM `pro` WHERE 1 ";
				$res = mysqli_query($conn, $sql);

				
				if($res){
					$count  = mysqli_num_rows($res); 
					$sn=1;
					if($count > 0){
						while($row = mysqli_fetch_assoc($res)){
							$id = $row['id'];
							$name = $row['name'];
							$image_name = $row['image_name'];
							$price = $row['price'];
							$des = $row['description'];
							?>

							<div class="product">
							<?php if($image_name!=''){
                               ?>
							<img src='<?php echo SIT; ?>images/pro/<?php echo $image_name; ?>' alt="Product 1">
							<?php
                            } else{
                                echo "no image";
                            }?>

							<h3><?php echo $name; ?></h3>
							
							<p><?php echo $des; ?></p>

							<span>$<?php echo $price; ?></span>

							<button>Add to Cart</button>
						</div>

		<?php

						}
					}
				}


?>
		
</section>
<footer>
<ul>
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Terms of Service</a></li>
<li><a href="#">Returns and Refunds</a></li>
</ul>
<p>© 2023 Best E-commerce Website</p>
</footer>

</body>
</html>