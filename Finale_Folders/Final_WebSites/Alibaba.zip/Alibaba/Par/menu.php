<?php include('config.php');  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    
</head>
<body>
   
   <section class="first-part">
       <div class="cont">
            
                <img src="images/land.jpg" alt="logo" width='10%' height='20%' class="logo">
            
            <div class="menu right">
            <ul>
                
                <li>
                    <a href="<?php echo SIT; ?>index.php">Home</a>
                </li>
                <li>
                    <a href="#">Category</a>
                </li>
                <li>
                    <a href="#">Product</a>
                </li>
                 <li>
                    <a href="#">Sign In</a>
                </li>
                <li>
                    <a href="<?php echo SIT; ?>">order</a>
                </li>
            </ul>
        </div>
       </div>
       <div class="clear">