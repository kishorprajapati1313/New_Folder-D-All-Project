<html>
<head>
<title> Login Page Design </title>
   <link rel="stylesheet" type="text/css" href="css/log.css">
<body>
      <div class="loginbox">
      <center>
      <img src="images/p1.png" class="avatar">
       </center>
       <h3>Hello Guys Welcome Back to our Login Page</h3>
            <h1>Login Here</h1>
      <form method="post">
          <p>Username</p>
          <input type="text" name="" placeholder="Enter Username">
          <p>Password</p>
          <input type="password" placeholder="Enter Password">
          <input type="Submit" name="" value="Login">
        </form>
        <div class="link">You Forgot your password? <a href="forgot.php">Forgot password</a></div><div></div>
        <div class="link">Not yet signed up? <a href="sign.php">Signup now</a></div>
  
  
  
  <?php 
  
      if(isset($_POST['submit']))
      {
          $user = $_POST['user'];
          $password = $_POST['password'];
  
          $sql = "SELECT * FROM sign WHERE username='$user' AND password='$password'";
          $res = mysqli_query($conn, $sql);
  
          $count = mysqli_num_rows($res);
  
          if ($count == 1)
          {
              $_SESSION['user'] = $user;
              header('location:'.SIT.'index.php');
          }
  
          else{
              header('location:'.SIT.'login.php');
          }
      }
  
  
  
  ?>
  
  
      </form>

      </div>
</body>
</head>
</html>