<?php include('../Par/config.php');  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/admin.css">
    <title>Document</title>
</head>
<body>

<section class="menu center">
   
        <div class="floating ">
            <ul>
                <li><a href="home.php">Home</a> </li>
                <li><a href="admin.php">Admin</a> </li>
                <li><a href="section.php">Section</a></li>
                <li><a href="product.php">Product</a> </li>
                <li><a href="order.php">Order</a> </li>
                
            </ul>
        </div>
        <div class="clear"></div>
    
</section>