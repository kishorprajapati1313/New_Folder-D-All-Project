<?php 
    include('../Par/config.php');

    if(isset($_GET['id'])){
        $id = $_GET['id'];

        $sql = "DELETE FROM pro WHERE id='$id'";

        $res = mysqli_query($conn, $sql);

        if($res==true){
            $_SESSION['delete'] = "<div class='s'>Deleted Product</div>";
            header("location:".SIT."admin/product.php");
        }else{
            $_SESSION['delete'] = "<div class='f'>Deleted Product Failed</div>";
            header("location:".SIT."admin/product.php");
        }
    }



?>