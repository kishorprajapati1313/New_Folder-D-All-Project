<?php include('../ad-par/menu.php');  ?> 

<section class="main">
    <h1>Add Product</h1>
    <?php
        if(isset($_SESSION['upload'])){
            echo $_SESSION['upload'];
            unset($_SESSION['upload']);
        }
    ?><br><br>
    <form action="" method='POST' enctype='multipart/form-data'>
        <table class="tbl-30">
            <tr>
                <td>Product Name:</td>
                <td><input type='text' name='name'></td>
            </tr>

            <tr>
                <td>Description:</td>
                <td><textarea name='description' rows='4' placeolder='Enter Description'></textarea></td>
            </tr>

            <tr>
                <td>Price:</td>
                <td><input type='number' name='price' placeholder='enter price'</td>
            </tr>

            <tr>
                <td>Select Iamge:</td>
                <td><input type='file' name='image'></td>
            </tr>

            <tr>
                <td>Seclect Section:</td>
                <td>
                    <select name='section'>
                        <?php
                            $sql = "SELECT * FROM section ";
                            $res = mysqli_query($conn, $sql);

                            $count = mysqli_num_rows($res);

                            if($count>0){
                                while($row=mysqli_fetch_assoc($res)){
                                    $section_id = $row['id'];
                                    $section_name = $row['name'];
                                    ?>
                                    <option <?php echo $section_id; ?>><?php echo $section_name; ?></option>
                                    <?php
                                }
                            }else{
                            ?>
                            <option value='0'>No Category</option>  
                            <?php
                            }
                        ?>
                        
                    </select>
                </td>
            </tr>

            <tr>
                <td>Fectured:</td>
                <td><input type='radio' name='fectured' value='yes'>yes
                <input type='radio' name='fectured' value='no'>no</td>
            </tr>

            <tr>
                <td>Active:</td>
                <td><input type='radio' name='active' value='yes'>yes
                <input type='radio' name='active' value='no'>no</td>
            </tr>

            <tr colspan='2'>
                <td><input type='submit' name='submit' value='Add Product' class='btn-s'></td>
            </tr>
        </table>
    </form>
</section>


<?php include('../ad-par/footer.php');  ?> 

<?php 

    if(isset($_POST['submit'])){
        $name = $_POST['name'];
        $price = $_POST['price'];
        $description = $_POST['description'];
        $section_id = $_POST['section'];

        if(isset($_POST['fectured'])){
            $fectured = $_POST['fectured'];
        }else{
            $fectured = "no";
        }

        if(isset($_POST['active'])){
            $active = $_POST['active'];
        }else{
            $active = "no";
        }

                   //get the image button clicked or not
                   if(isset($_FILES['image']['name'])){
                    $image_name = $_FILES['image']['name'];
      
                      //image selected or not
                          if($image_name!=""){
                              //image selected
                              $ext = end(explode('.',$image_name)); //old image name would be first.jpg
      
                              $image_name = "Product".rand(0000,9999).".".$ext;   //new name will be "book name -890.jpg"
      
                              //upload the image-name
                              $src = $_FILES['image']['tmp_name'];
      
                              $dst = "../images/pro/".$image_name;
      
                                  //image move to our folder
                              $upload = move_uploaded_file($src, $dst);
      
                              if($upload==false){
                                  $_SESSION['upload'] = "<div class='f'>not upload the image</div>";
                                  header('location:'.SIT.'admin/product-add.php');
                                  die();
                              }
                          }
                 }else{
                  $image_name="";
                 }

        $sql2 = "INSERT INTO `pro`(`name`, `price`, `description`, `image_name`, `section`, `fectured`, `active`) VALUES 
        ('$name','$price','$description','$image_name','$section_id','$fectured','$active')";

         $res2 = mysqli_query($conn, $sql2);

         if($res2 == true){
            $_SESSION['add'] = "<div class='s'>New Product Added</div>";
            header('location:'.SIT."admin/product.php");
         }else{
            $_SESSION['add'] = "<div class='f'>Failed to add product</div>";
            header('location:'.SIT."admin/product.php");
         }

    }


?>