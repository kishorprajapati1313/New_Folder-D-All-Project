<?php include('../ad-par/menu.php');  ?> 


<section class="main">
    <h1>Update Product</h1><br><br>
    <?php
if(isset($_GET['id'])){
    $id = $_GET['id'];

    $sql = "SELECT * FROM pro WHERE id=$id ";
    
    $res = mysqli_query($conn, $sql);

    $count = mysqli_num_rows($res);

    if($count==1){
        $row = mysqli_fetch_assoc($res);
        $name = $row['name'];
        $description = $row['description'];
        $price = $row['price'];
        $current_image = $row['image_name'];
        $fectured = $row['fectured'];
        $section_id = $row['section'];
        $active = $row['active'];
    }
}
        if(isset($_SESSION['upload'])){
            echo $_SESSION['upload'];
            unset($_SESSION['upload']);
        }

        if(isset($_SESSION['r-f'])){
            echo $_SESSION['r-f'];
            unset($_SESSION['r-f']);
        }
?>

    <form action="" method='POST' enctype='multipart/form-data'>
        <table class="tbl-30">
            <tr>
                <td>Name:</td>
                <td><input type='text' name='name' value='<?php echo  $name ;?>'></td>
            </tr>

            <tr>
                <td>Description:</td>
                <td><textarea name='description' ><?php echo  $description; ?></textarea></td>
            </tr>

            <tr>
                <td>Price:</td>
                <td><input type='number' name='price' value='<?php echo  $price ;?>'></td>
            </tr>

            <tr>
                <td>Current Image:</td>
                <td>
                    <?php
                    if($current_image!=''){
                        ?>
                        <img src='<?php echo SIT; ?>images/pro/<?php echo $current_image; ?>' height='50px' width='80px'>
                        <?php
                    }else{
                        $current_image = "no image";
                    }
                    ?>
                </td>
            </tr>

            <tr>
                <td>Select Image:</td>
                <td><input type='file' name='image'></td>
            </tr>

            <tr>
                <td>Section:</td>
                <td><select name='section'>
                    <?php 
                        $sql2 = "SELECT * FROM section ";
                        $res2 = mysqli_query($conn, $sql2);

                        $count2 = mysqli_num_rows($res2);

                            if($count2>0){
                                while($row=mysqli_fetch_assoc($res2)){
                                    $section = $row['id'];
                                    $section_name = $row['name'];
                                    ?>
                                    <option <?php if($section_id == $section_name){echo 'selected';} ?> value='<?php echo $section; ?>'><?php echo $section_name; ?></option>
                                    <?php
                                }
                            }else{
                            ?>
                            <option value='0'>No Category</option>  
                            <?php
                            }
                    ?>
                </select></td>
            </tr>

            <tr>
                <td>Fectured:</td>
                <td><input <?php if($fectured == 'yes'){echo "checked"; }?> name='fectured' type='radio' value="<?php echo $fectured; ?>">yes
                <input <?php if($fectured == 'no'){echo "checked"; }?> name='fectured' type='radio' value="<?php echo $fectured; ?>">no</td>
            </tr>

            <tr>
                <td>Active:</td>
                <td><input <?php if($active == 'yes'){echo "checked"; }?> name='active' type='radio' value="<?php echo $active; ?>">yes
                <input <?php if($active == 'no'){echo "checked"; }?> name='active' type='radio' value="<?php echo $active; ?>">no</td>
            </tr>
            
            <tr>
                <td colspan='2'>
                    <input type='hidden' name='id' value='<?php echo $id; ?>' >
                    <input type='hidden' name='current_image' value='<?php echo $current_image; ?>' >
                    <input type="submit" name='submit' value='Update Product' class='btn-s'>
                </td>
            </tr>
        </table>
    </form>
</section>

<?php include('../ad-par/footer.php');  ?> 

<?php

    if(isset($_POST['submit'])){
        $id = $_POST['id'];
        $name = $_POST['name'];
        $price = $_POST['price'];
        $description = $_POST['description'];
        $current_image = $_POST['current_image'];
        $section = $_POST['section'];

        if($fectured = 'yes'){
            $fectured = $_POST['fectured'];
        }else{
            $fectured = 'no';
        }

        if($active = 'yes'){
            $active = $_POST['fectured'];
        }else{
            $active = 'no';
        }

        if(isset($_FILES['image']['name'])){
            //button clicked
            $image_name = $_FILES['image']['name'];  //new image

            //file is avaliable or not
            if($image_name!=''){
                //image avaliable
                $ext = end(explode('.', $image_name));
                $image_name = 'product'.rand(0000,9999).'.'.$ext;

                //get the source path
                $src_path = $_FILES['image']['tmp_name'];

                $dest_path = "../images/pro/".$image_name;

                $upload = move_uploaded_file($src_path, $dest_path);

                //check image upload or nt
                if($upload==false){
                    $_SESSION['upload'] = '<div class="e">not upload the img</div>';
                    header('location:'.SIT.'admin/product-update.php');
                    die();
                }

                //3 remove the image if new image uploaded an

                //remove img if avaliable
                if($current_image!=''){
                    //avaliable
                    $remove_path = "../images/pro/".$current_image;
                    $remove = unlink($remove_path);
                    if($remove==false){
                        $_SESSION['remove-failed'] = '<div class="e">not upload</div>';
                        header('location:'.SIT.'admin/product-update.php');
                        die();
                    }
                }
            }
            else{
                $image_name = $current_image;

            }

    }else{
        $image_name = $current_image;
    }


        $sql3 = "UPDATE pro SET
        `name`='$name',`description`='$description',`price`='$price',
        `section`='$section',`fectured`='$fectured',`active`='$active',`image_name`='$image_name' WHERE id=$id";


$res3 = mysqli_query($conn, $sql3);

if($res3==true){
    $_SESSION['update'] = '<div class="s">upload</div>';
    header('location:'.SIT.'admin/product.php');

}else{
    $_SESSION['update'] = '<div class="f"> not upload</div>';
    header('location:'.SIT.'admin/product.php');


}




    }

?>