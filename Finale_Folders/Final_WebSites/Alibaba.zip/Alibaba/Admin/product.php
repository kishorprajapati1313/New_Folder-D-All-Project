<?php include('../ad-par/menu.php');  ?> 

<section class="main">
<h1>Manage Product</h1><br>
<?php
        if(isset($_SESSION['add'])){
            echo $_SESSION['add'];
            unset($_SESSION['add']);
        }
        if(isset($_SESSION['delete'])){
            echo $_SESSION['delete'];
            unset($_SESSION['delete']);
        }

        if(isset($_SESSION['update'])){
            echo $_SESSION['update'];
            unset($_SESSION['update']);
        }
    ?><br><br>
<form action="" method='post'>
    <a href="<?php echo SIT; ?>admin/product-add.php" class='btn-p'>Add admin</a><br><br><br><br>
    <table class="tbl">
            <tr>
                <th>S.N</th>
                <th>Product-Name</th>
                <th>Price</th>
                <th>Image</th>
                <th>Fectured</th>
                <th>Active</th>
                <th>Action</th>
            </tr>

            <tr>
                <?php
                $sql = "SELECT * FROM pro ";

                $res = mysqli_query($conn, $sql);

                $count = mysqli_num_rows($res);
                $sn=1;

                if($count>0){
                    while($row = mysqli_fetch_assoc($res)){
                        $id = $row['id'];
                        $name = $row['name'];
                        $price = $row['price'];
                        $description = $row['description'];
                        $image_name = $row['image_name'];
                        $fectured = $row['fectured'];
                        $active = $row['active'];
                        ?>
                            <td><?php echo $sn++; ?></td>
                            <td><?php echo $name; ?></td>
                            <td><?php echo $price; ?></td>

                            <td><?php if($image_name!=''){
                               ?>
                               <img src='<?php echo SIT; ?>images/pro/<?php echo $image_name; ?>' height='60px' width='80px'>
                               <?php
                            } else{
                                echo "no image";
                            }?></td>

                            <td><?php echo $fectured; ?></td>
                            <td><?php echo $active; ?></td>
                            <td>
                                <a href="<?php echo SIT; ?>admin/product-update.php?id=<?php echo $id; ?>" class="btn-s ">Update Product</a>
                                <a href="<?php echo SIT; ?>admin/product-delete.php?id=<?php echo $id; ?>" class="btn-d"> Delete Product</a>
                            </td>
                        </tr>
                        <?php
                                }
                            }

                            ?>
                
</table>
</form>
</section>


<?php include('../ad-par/footer.php');  ?> 