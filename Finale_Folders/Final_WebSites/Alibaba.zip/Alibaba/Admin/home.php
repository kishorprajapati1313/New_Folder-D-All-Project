<?php include('../ad-par/menu.php');  ?> 

   
<section class="main">
<br>
         <h1> DASHBOARD</h1>
            <div class="wer">
            

            <div class="col center">
                <?php
                    $sql = "SELECT * FROM section ";
                    $res = mysqli_query($conn, $sql);
                    $count = mysqli_num_rows($res);
                ?>
            <p class='font-2'><b><?php echo $count; ?></b></p><br>
            <p class='font'>Section</p>
            </div>

            <div class="col center">

            <?php 
            $sql = "SELECT * FROM pro "; 
                $res = mysqli_query($conn, $sql);
                $count = mysqli_num_rows($res);
?>
                
            <p class='font-2'><b><?php echo $count; ?></b></p><br>
            <p class='font'>Prouduct</p>
            </div>

            <div class="col center">
            <p class='font-2'><b>0</b></p><br>
            <p class='font'>Order</p>
            </div>

            <div class="col center">
            <p class='font-2'><b>$0</b></p><br>
            <p class='font'>Revenue</p>
            </div>
            
        <div class="clear"></div>
    
</section>
    
<?php include('../ad-par/footer.php');  ?>  