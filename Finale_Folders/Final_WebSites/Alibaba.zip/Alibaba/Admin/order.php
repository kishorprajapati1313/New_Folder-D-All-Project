<?php include('../ad-par/menu.php');  ?> 

<section class="main">
<h1>Manage Order</h1><br>
<form action="" method='post'><br><br>
    <table class="tbl">
            <tr>
                <th>S.N</th>
                <th>Name</th>
                <th>Qty</th>
                <th>Total</th>
                <th>Date-time</th>
                <th>Status</th>
                <th>customer Name</th>
                <th>Customer Contact</th>
                <th>Customer Email</th>
                <th>Customer Address</th>
                <th>Action</th>
            </tr>

            <tr>
            <td>S.N</td>
                <td>Name</td>
                <td>Quantity</td>
                <td>Total</td>
                <td>Order Date</td>
                <td>Status</td>
                <td>customer Name</td>
                <td>Customer Contact</td>
                <td>Customer Email</td>
                <td>Customer Address</td>
                <td>
                 <a href="#" class="btn-s ">Update Order</a>
                    
                </td>
            </tr>
</table>
</form>
</section>








<?php include('../ad-par/footer.php');  ?> 