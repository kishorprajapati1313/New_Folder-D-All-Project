<?php include('../ad-par/menu.php');  ?> 



<section class="main">
    <h1>Change Password</h1><br><br> 
        <?php 
        if(isset($_GET['id'])){
            $id=$_GET['id'];
        }?>
        <form action='' method='POST'>
            <table class='tbl-30'>
                <tr>
                    <td>Old password:</td>
                    <td><input type='password' name='c_p' placeholder='old password'></td>
                </tr>
                <tr>
                    <td>New password:</td>
                    <td><input type='password' name='n_p' placeholder='new password'></td>

                </tr>
                <tr>
                    <td>Conform_password</td>
                    <td>
                        <input type='password' name='co_p' placeholder='conform password'>
                    </td>
                </tr>
                <tr>
                    <td colspan='2'>
                        <input type='hidden' name='id' value='<?php echo $id;?>'>
                        <input type='submit' name='submit' value='change password' class='btn-s'>
                    </td>
                </tr>
            </table>


        </form>

</section>

<?php include('../ad-par/footer.php');  ?> 

<?php 
        if(isset($_POST['submit'])){
            // get the from form
            $id= $_POST['id'];
            $c_p= $_POST['c_p'];
            $n_p= md5($_POST['n_p']);
            $co_p= md5($_POST['co_p']);

            //check the user with current id and password exists or not
            $sql="SELECT * FROM admin WHERE id=$id AND password='$c_p'";

            //execute the query
            $res= mysqli_query($conn, $sql);
            if($res==true){
                $count=mysqli_num_rows($res);
                if($count==1){
                    echo "user found";
                    if($n_p==$co_p){
                        //echo 'password is match';
                        $sql2="UPDATE admin SET
                        password='$n_p'
                        WHERE id = $id
                        ";
                        $res2=mysqli_query($conn, $sql2);

                        if($res2==true){
                            $_SESSION['c_p'] ="<div class='s'>password change successfully</div>";
                            header('location:'.SIT.'admin/admin.php');   
                        }else{
                            $_SESSION['c_p'] ="<div class='e'>password change fail</div>";
                            header('location:'.SIT.'admin/admin.php'); 
                        }
                    }else{
                        $_SESSION['p_m'] ="<div class='e'>password not match</div>";
                        header('location:'.SIT.'admin/admin.php');   
                    }

                }else{
                    $_SESSION['u_f'] ="<div class='e'>user not found</div>";
                    header('location:'.SIT.'admin/admin.php');
                }
            }

            // cheak the new password and conform new password match

            //change password if all above is true
        }
?>