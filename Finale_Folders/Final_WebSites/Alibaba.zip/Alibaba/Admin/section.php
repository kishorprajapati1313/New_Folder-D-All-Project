<?php include('../ad-par/menu.php');  ?> 

<section class="main">
<h1>Manage Section</h1><br>
<?php
   
    if(isset($_SESSION['add'])){
        echo $_SESSION['add'];
        unset($_SESSION['add']);
    }
    if(isset($_SESSION['update'])){
        echo $_SESSION['update'];
        unset($_SESSION['update']);
    }
    if(isset($_SESSION['delete'])){
        echo $_SESSION['delete'];
        unset($_SESSION['delete']);
    }
    
    if(isset($_SESSION['remove-failed'])){
        echo $_SESSION['remove-failed'];
        unset($_SESSION['remove-failed']);
    }

    if(isset($_SESSION['upload'])){
        echo $_SESSION['upload'];
        unset($_SESSION['upload']);
    }
?><br><br>
<form action="" method='post'>
    <a href="section-add.php" class='btn-p'>Add Section</a><br><br><br><br>
    <table class="tbl">
            <tr>
                <th>S.N</th>
                <th>Name</th>
                <th>Image</th>
                <th>Fectured</th>
                <th>Active</th>
                <th>Action</th>
            </tr>

            <?php
            $sql = "SELECT * FROM section WHERE 1 ";

            $res = mysqli_query($conn, $sql);

            if($res==true){
                $count = mysqli_num_rows($res);
                $sn=1;
                if($count>0){
                    while($row=mysqli_fetch_assoc($res)){
                        $id = $row['id'];
                        $name = $row['name'];
                        $image_name = $row['image_name'];
                        $fectured = $row['fectured'];
                        $active = $row['active'];
                        ?>

                        <tr>
                        <td><?php echo $sn++; ?></td>
                        <td><?php echo $name; ?></td>
                        <td><?php 
                                   if($image_name==''){
                                    echo "<div class='e'>not image</div>";
                                   }else{
                                    ?>
                                    <img src='<?php echo SIT; ?>images/se/<?php echo $image_name; ?>' width='90px' height='50px'>
                                    <?php
                                   }
                             ?></td>
                        <td><?php echo $fectured; ?></td>
                        <td><?php echo $active; ?></td>
                        <td>
                            <a href="<?php echo SIT; ?>admin/section-update.php?id=<?php echo $id; ?>" class="btn-s ">Update Section</a>
                            <a href="<?php echo SIT; ?>admin/section-delete.php?id=<?php echo $id; ?>" class="btn-d"> Delete Section</a>
                        </td>
                    </tr><?php
                        
                    }
                }
            }

?>

          
</table>
</form>
</section>

<?php include('../ad-par/footer.php');  ?> 